package com.example.data

import android.net.Uri

data class StudioBackground(
    val id: String,
    val name: String,
    val description: String,
    val category: BackgroundCategory,
    val assetResId: Int? = null,
    val customUri: Uri? = null,
    val themeColorHex: String
)

enum class BackgroundCategory {
    NEWS, PODCAST, POLITICAL, MODERN_TV, INTERVIEW, OFFICE, CUSTOM
}

data class NewsTickerItem(
    val id: String,
    val headline: String,
    val isBreaking: Boolean = true
)

data class BigScreenContent(
    val type: ScreenContentType,
    val uri: Uri? = null,
    val title: String = "LIVE BROADCAST",
    val textContent: String = "VIRTUAL STUDIO PRO 4K"
)

enum class ScreenContentType {
    IMAGE, VIDEO, SOLID_COLOR, GRAPHIC_SLIDE
}

data class RecordingItem(
    val id: String,
    val uri: Uri,
    val timestamp: Long,
    val durationSeconds: Int,
    val isVideo: Boolean
)
