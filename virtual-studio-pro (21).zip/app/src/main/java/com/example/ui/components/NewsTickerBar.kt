package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NewsTickerItem

@Composable
fun NewsTickerBar(
    tickerItems: List<NewsTickerItem>,
    modifier: Modifier = Modifier
) {
    val combinedText = tickerItems.joinToString(separator = "   ⚡   ") { it.headline }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFFB71C1C))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Breaking News badge
        Row(
            modifier = Modifier
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "BREAKING NEWS",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        // Scrolling ticker text
        Text(
            text = combinedText.ifEmpty { "VSP News 24/7 - Professional Virtual Studio Live Broadcast" },
            color = Color.White,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp,
            maxLines = 1
        )
    }
}
