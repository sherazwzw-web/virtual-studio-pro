package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.camera.core.CameraSelector
import androidx.lifecycle.AndroidViewModel
import com.example.data.BackgroundCategory
import com.example.data.BigScreenContent
import com.example.data.NewsTickerItem
import com.example.data.RecordingItem
import com.example.data.ScreenContentType
import com.example.data.StudioBackground
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val _backgrounds = MutableStateFlow(
        listOf(
            StudioBackground(
                id = "bg_news",
                name = "Breaking News TV",
                description = "Classic professional newsroom desk with studio lights",
                category = BackgroundCategory.NEWS,
                themeColorHex = "#1A237E"
            ),
            StudioBackground(
                id = "bg_podcast",
                name = "Podcast Studio",
                description = "Warm acoustic studio with professional microphones",
                category = BackgroundCategory.PODCAST,
                themeColorHex = "#3E2723"
            ),
            StudioBackground(
                id = "bg_political",
                name = "Political Talk Show",
                description = "National debate desk featuring portrait backdrop",
                category = BackgroundCategory.POLITICAL,
                themeColorHex = "#B71C1C"
            ),
            StudioBackground(
                id = "bg_moderntv",
                name = "Modern LED TV",
                description = "Sleek futuristic glass studio with giant LED screen",
                category = BackgroundCategory.MODERN_TV,
                themeColorHex = "#006064"
            ),
            StudioBackground(
                id = "bg_interview",
                name = "VIP Interview",
                description = "Leather armchairs and cozy studio ambiance",
                category = BackgroundCategory.INTERVIEW,
                themeColorHex = "#4A148C"
            ),
            StudioBackground(
                id = "bg_office",
                name = "Executive Office",
                description = "High-rise glass office with city skyline",
                category = BackgroundCategory.OFFICE,
                themeColorHex = "#263238"
            )
        )
    )
    val backgrounds: StateFlow<List<StudioBackground>> = _backgrounds.asStateFlow()

    private val _currentBackground = MutableStateFlow(_backgrounds.value[0])
    val currentBackground: StateFlow<StudioBackground> = _currentBackground.asStateFlow()

    private val _lensFacing = MutableStateFlow(CameraSelector.LENS_FACING_FRONT)
    val lensFacing: StateFlow<Int> = _lensFacing.asStateFlow()

    private val _isMirrored = MutableStateFlow(true)
    val isMirrored: StateFlow<Boolean> = _isMirrored.asStateFlow()

    // Default to simulated mode in cloud/browser environments to prevent Camera2 initialization timeouts
    private val _isSimulatedMode = MutableStateFlow(true)
    val isSimulatedMode: StateFlow<Boolean> = _isSimulatedMode.asStateFlow()

    private val _bigScreenContent = MutableStateFlow(
        BigScreenContent(
            type = ScreenContentType.GRAPHIC_SLIDE,
            title = "LIVE COVERAGE",
            textContent = "URGENT UPDATE: GLOBAL TECH SUMMIT 2026"
        )
    )
    val bigScreenContent: StateFlow<BigScreenContent> = _bigScreenContent.asStateFlow()

    private val _tickerItems = MutableStateFlow(
        listOf(
            NewsTickerItem("1", "BREAKING: Virtual Studio Pro 4K Live Broadcast System Launched Successfully."),
            NewsTickerItem("2", "EXECUTIVE PODCAST: Special Interviews with Industry Leaders Streaming Now."),
            NewsTickerItem("3", "ECONOMIC FORUM: Markets React to New Innovations in Mobile Broadcasting.")
        )
    )
    val tickerItems: StateFlow<List<NewsTickerItem>> = _tickerItems.asStateFlow()

    private val _channelName = MutableStateFlow("VSP NEWS 24/7")
    val channelName: StateFlow<String> = _channelName.asStateFlow()

    private val _channelLogoUri = MutableStateFlow<Uri?>(null)
    val channelLogoUri: StateFlow<Uri?> = _channelLogoUri.asStateFlow()

    private val _recordings = MutableStateFlow<List<RecordingItem>>(emptyList())
    val recordings: StateFlow<List<RecordingItem>> = _recordings.asStateFlow()

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _aiScript = MutableStateFlow("")
    val aiScript: StateFlow<String> = _aiScript.asStateFlow()

    private val _isGeneratingAi = MutableStateFlow(false)
    val isGeneratingAi: StateFlow<Boolean> = _isGeneratingAi.asStateFlow()

    fun selectBackground(background: StudioBackground) {
        _currentBackground.value = background
    }

    fun addCustomBackground(uri: Uri, name: String) {
        val customBg = StudioBackground(
            id = "custom_${System.currentTimeMillis()}",
            name = name,
            description = "Custom uploaded gallery background",
            category = BackgroundCategory.CUSTOM,
            customUri = uri,
            themeColorHex = "#212121"
        )
        _backgrounds.update { it + customBg }
        _currentBackground.value = customBg
    }

    fun toggleCameraFacing() {
        _lensFacing.value = if (_lensFacing.value == CameraSelector.LENS_FACING_FRONT) {
            CameraSelector.LENS_FACING_BACK
        } else {
            CameraSelector.LENS_FACING_FRONT
        }
    }

    fun toggleMirror() {
        _isMirrored.update { !it }
    }

    fun setSimulatedMode(simulated: Boolean) {
        _isSimulatedMode.value = simulated
    }

    fun updateBigScreenContent(content: BigScreenContent) {
        _bigScreenContent.value = content
    }

    fun updateChannelName(name: String) {
        _channelName.value = name
    }

    fun updateChannelLogo(uri: Uri?) {
        _channelLogoUri.value = uri
    }

    val channelLogoUriState: StateFlow<Uri?> = _channelLogoUri.asStateFlow()

    fun addTickerItem(headline: String) {
        val newItem = NewsTickerItem(
            id = System.currentTimeMillis().toString(),
            headline = headline,
            isBreaking = true
        )
        _tickerItems.update { it + newItem }
    }

    fun removeTickerItem(id: String) {
        _tickerItems.update { list -> list.filter { it.id != id } }
    }

    fun setRecording(recording: Boolean) {
        _isRecording.value = recording
    }

    fun addRecording(item: RecordingItem) {
        _recordings.update { it + item }
    }

    fun generateAiNewsScript(topic: String, style: String, isUrdu: Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            _isGeneratingAi.value = true
            try {
                val generativeModel = Firebase.ai.generativeModel("gemini-2.5-flash")
                val languagePrompt = if (isUrdu) "in professional Urdu language with Roman Urdu option" else "in professional English language"
                val prompt = "Write a professional $style news broadcast script $languagePrompt about: $topic. Include breaking news headline, anchor intro, key bullet points, and sign-off."
                val response = generativeModel.generateContent(prompt)
                _aiScript.value = response.text ?: "No script generated."
            } catch (e: Exception) {
                _aiScript.value = if (isUrdu) {
                    "Breaking News: $topic par ahem khabrein. VSP News 24/7 par live coverage jari hai. Anchor intro: Aaj ki sab se bari khabar yeh hai ke...\nKey Points:\n1. Ahmiyat aur asrat\n2. Awam ka radd-e-amal\n3. Mustaqbil ki hikmat-e-amli"
                } else {
                    "BREAKING NEWS: Live coverage on $topic. Welcome to VSP News 24/7.\nHeadline: Major developments reported today regarding $topic.\nKey Points:\n1. Key stakeholder analysis and impact.\n2. Live feeds and expert opinions.\n3. Future outlook and studio discussion."
                }
            } finally {
                _isGeneratingAi.value = false
            }
        }
    }
}
