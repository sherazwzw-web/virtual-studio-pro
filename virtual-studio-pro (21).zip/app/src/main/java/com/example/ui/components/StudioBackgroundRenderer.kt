package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.BigScreenContent
import com.example.data.StudioBackground

private val GoldColor = Color(0xFFFFD700)

@Composable
fun StudioBackgroundRenderer(
    background: StudioBackground,
    bigScreenContent: BigScreenContent,
    channelName: String,
    channelLogoUri: android.net.Uri?,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.fillMaxSize()) {
        // 1. Virtual Studio Background Layer (Behind Presenter)
        when (background.id) {
            "bg_news" -> NewsStudioBackground()
            "bg_podcast" -> PodcastStudioBackground()
            "bg_political" -> PoliticalStudioBackground()
            "bg_moderntv" -> ModernTvStudioBackground(bigScreenContent)
            "bg_interview" -> InterviewStudioBackground()
            "bg_office" -> OfficeStudioBackground()
            else -> {
                if (background.customUri != null) {
                    AsyncImage(
                        model = background.customUri,
                        contentDescription = background.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    NewsStudioBackground()
                }
            }
        }

        // 2. Presenter Camera Preview
        content()

        // 3. Studio Foreground Elements (Big Screen Monitor if not Modern TV)
        if (background.id != "bg_moderntv") {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.TopEnd
            ) {
                BigScreenOverlay(bigScreenContent)
            }
        }

        // 4. Channel Header & On-Air Badge
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val infiniteTransition = rememberInfiniteTransition(label = "live_blink")
            val alphaAnim by infiniteTransition.animateFloat(
                initialValue = 0.3f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "alpha"
            )

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Red.copy(alpha = 0.8f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = alphaAnim))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LIVE",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .border(1.dp, GoldColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (channelLogoUri != null) {
                    AsyncImage(
                        model = channelLogoUri,
                        contentDescription = "Logo",
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = channelName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun NewsStudioBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0D1B2A), Color(0xFF1B263B), Color(0xFF000814))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawLine(
                color = Color(0xFF415A77).copy(alpha = 0.3f),
                start = Offset(w * 0.2f, 0f),
                end = Offset(w * 0.2f, h),
                strokeWidth = 4f
            )
            drawLine(
                color = Color(0xFF415A77).copy(alpha = 0.3f),
                start = Offset(w * 0.8f, 0f),
                end = Offset(w * 0.8f, h),
                strokeWidth = 4f
            )
        }
    }
}

@Composable
fun PodcastStudioBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF3E2723), Color(0xFF1E110F), Color(0xFF0A0504))
                )
            )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            repeat(10) {
                Spacer(modifier = Modifier.height(30.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .background(Color(0xFF5D4037).copy(alpha = 0.4f))
                )
            }
        }
    }
}

@Composable
fun PoliticalStudioBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF4A0000), Color(0xFF1A0000), Color(0xFF050000))
                )
            )
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
                .size(120.dp)
                .clip(CircleShape)
                .background(Color(0xFF8B0000))
                .border(2.dp, GoldColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Leader Portrait",
                    tint = GoldColor,
                    modifier = Modifier.size(60.dp)
                )
                Text(
                    text = "VISION 2026",
                    color = GoldColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ModernTvStudioBackground(bigScreenContent: BigScreenContent) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF051923))
    ) {
        Card(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF003554)),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                if (bigScreenContent.uri != null) {
                    AsyncImage(
                        model = bigScreenContent.uri,
                        contentDescription = "LED Screen Content",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = "LED Screen",
                            tint = Color(0xFF00A8E8),
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = bigScreenContent.title,
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = bigScreenContent.textContent,
                            color = Color(0xFF90E0EF),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InterviewStudioBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF31103A), Color(0xFF15051A), Color(0xFF07010A))
                )
            )
    )
}

@Composable
fun OfficeStudioBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF1C2833), Color(0xFF111822), Color(0xFF0B0F15))
                )
            )
    )
}

@Composable
fun BigScreenOverlay(bigScreenContent: BigScreenContent) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .height(110.dp)
            .padding(top = 50.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.8f)),
        border = BorderStroke(1.dp, Color(0xFF00ADB5)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            if (bigScreenContent.uri != null) {
                AsyncImage(
                    model = bigScreenContent.uri,
                    contentDescription = "Preview",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = bigScreenContent.title,
                        color = Color.Cyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = bigScreenContent.textContent,
                        color = Color.White,
                        fontSize = 9.sp,
                        maxLines = 2
                    )
                }
            }
        }
    }
}
