package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun StudioControlPanel(
    isRecording: Boolean,
    isSimulatedMode: Boolean,
    onToggleSimulatedMode: () -> Unit,
    onToggleRecording: () -> Unit,
    onSwitchCamera: () -> Unit,
    onToggleMirror: () -> Unit,
    onOpenBackgrounds: () -> Unit,
    onOpenBigScreen: () -> Unit,
    onOpenAiGenerator: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color.Black.copy(alpha = 0.85f),
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Simulated vs Live Camera Toggle
            IconButton(onClick = onToggleSimulatedMode) {
                Icon(
                    imageVector = if (isSimulatedMode) Icons.Default.Person else Icons.Default.Videocam,
                    contentDescription = "Toggle Camera Mode",
                    tint = if (isSimulatedMode) Color(0xFF00ADB5) else Color.White
                )
            }

            // Camera Flip
            IconButton(onClick = onSwitchCamera) {
                Icon(
                    imageVector = Icons.Default.FlipCameraAndroid,
                    contentDescription = "Switch Camera",
                    tint = Color.White
                )
            }

            // Backgrounds Picker
            IconButton(onClick = onOpenBackgrounds) {
                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = "Studio Backgrounds",
                    tint = Color(0xFF00ADB5)
                )
            }

            // Big Screen LED
            IconButton(onClick = onOpenBigScreen) {
                Icon(
                    imageVector = Icons.Default.Tv,
                    contentDescription = "Big Screen LED",
                    tint = Color(0xFF00ADB5)
                )
            }

            // AI Script Generator
            IconButton(onClick = onOpenAiGenerator) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI News Script",
                    tint = Color(0xFFFFD700)
                )
            }

            // Main Record / Shutter Button
            IconButton(
                onClick = onToggleRecording,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(if (isRecording) Color.Red else Color.White)
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.RadioButtonChecked,
                    contentDescription = "Record",
                    tint = if (isRecording) Color.White else Color.Red,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}
