package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.StudioViewModel
import com.example.ui.components.BackgroundSelectionSheet
import com.example.ui.components.BigScreenDialog
import com.example.ui.components.CameraPreviewView
import com.example.ui.components.NewsTickerBar
import com.example.ui.components.StudioBackgroundRenderer
import com.example.ui.components.StudioControlPanel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioMainScreen(
    viewModel: StudioViewModel,
    onNavigateToAiScript: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentBackground by viewModel.currentBackground.collectAsState()
    val backgrounds by viewModel.backgrounds.collectAsState()
    val lensFacing by viewModel.lensFacing.collectAsState()
    val isMirrored by viewModel.isMirrored.collectAsState()
    val isSimulatedMode by viewModel.isSimulatedMode.collectAsState()
    val bigScreenContent by viewModel.bigScreenContent.collectAsState()
    val tickerItems by viewModel.tickerItems.collectAsState()
    val channelName by viewModel.channelName.collectAsState()
    val channelLogoUri by viewModel.channelLogoUri.collectAsState()
    val isRecording by viewModel.isRecording.collectAsState()

    var showBackgroundSheet by remember { mutableStateOf(false) }
    var showBigScreenDialog by remember { mutableStateOf(false) }

    val bgSheetState = rememberModalBottomSheetState()
    val bigScreenSheetState = rememberModalBottomSheetState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                NewsTickerBar(tickerItems = tickerItems)
                StudioControlPanel(
                    isRecording = isRecording,
                    isSimulatedMode = isSimulatedMode,
                    onToggleSimulatedMode = { viewModel.setSimulatedMode(!isSimulatedMode) },
                    onToggleRecording = { viewModel.setRecording(!isRecording) },
                    onSwitchCamera = { viewModel.toggleCameraFacing() },
                    onToggleMirror = { viewModel.toggleMirror() },
                    onOpenBackgrounds = { showBackgroundSheet = true },
                    onOpenBigScreen = { showBigScreenDialog = true },
                    onOpenAiGenerator = onNavigateToAiScript
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Virtual Studio Background + Camera / Presenter Layer
            StudioBackgroundRenderer(
                background = currentBackground,
                bigScreenContent = bigScreenContent,
                channelName = channelName,
                channelLogoUri = channelLogoUri,
                modifier = Modifier.fillMaxSize()
            ) {
                CameraPreviewView(
                    lensFacing = lensFacing,
                    isMirrored = isMirrored,
                    isSimulatedMode = isSimulatedMode,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        if (showBackgroundSheet) {
            ModalBottomSheet(
                onDismissRequest = { showBackgroundSheet = false },
                sheetState = bgSheetState
            ) {
                BackgroundSelectionSheet(
                    backgrounds = backgrounds,
                    currentBackground = currentBackground,
                    onSelectBackground = { bg ->
                        viewModel.selectBackground(bg)
                        showBackgroundSheet = false
                    },
                    onAddCustomBackground = { uri, name ->
                        viewModel.addCustomBackground(uri, name)
                    },
                    onDismiss = { showBackgroundSheet = false }
                )
            }
        }

        if (showBigScreenDialog) {
            ModalBottomSheet(
                onDismissRequest = { showBigScreenDialog = false },
                sheetState = bigScreenSheetState
            ) {
                BigScreenDialog(
                    currentContent = bigScreenContent,
                    onUpdateContent = { content ->
                        viewModel.updateBigScreenContent(content)
                    },
                    onDismiss = { showBigScreenDialog = false }
                )
            }
        }
    }
}
